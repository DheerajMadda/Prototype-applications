import { Component, OnInit } from '@angular/core';
import * as io from 'socket.io-client';

@Component({
  selector: 'app-webs',
  templateUrl: './webs.component.html',
  styleUrls: ['./webs.component.css']
})
export class WebsComponent implements OnInit {

  
  t:any = 0;
  h:any = 1;
  socket: SocketIOClient.Socket;

    constructor(){
      this.socket = io.connect('http://127.0.0.1:3000');
      this.socket.on('key',(payload) =>{
        console.log(payload);
        this.t= payload.temp;
        this.h= payload.humi;
    });
    }

  ngOnInit() {
  
  }

}
